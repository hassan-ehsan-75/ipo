<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/png" href="{{asset('images/app_images/logoo.png')}}" />
    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="{{asset('assets/bootstrap/css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/fonts/font-awesome.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/rtl.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/Sidebar-Menu-1.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/Sidebar-Menu.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/styles.css')}}">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <style>
      
        </style>
        <title>
        @yield("title")
        </title>
    @yield('css')
</head>
<body>
<section id="loading" class="loading">
    <div id="loading-content" class="loading-content"></div>
  </section>
<div id="wrapper">
    <div id="sidebar-wrapper">
    <div class="wrapper-image">
        <img src="{{asset('images/app_images/logoo.png')}}">
    </div>
        <ul class="sidebar-nav">
            <li><a href="{{route('home')}}">الصفحة الرئيسية</a></li>
            @if(Auth::User()->hasRole('view_company'))
            <li><a href="{{url('/companies')}}">الشركات </a></li>
            @endif
            @if(Auth::User()->hasRole('view_bank'))
            <li><a href="{{url('banks')}}">البنوك </a></li>
            @endif
            @if(Auth::User()->hasRole('view_branch'))
            <li><a href="{{url('branches')}}">أفرع البنوك </a></li>
            @endif
            @if(Auth::User()->hasRole('view_stock'))
            <li><a href="{{url('stocks')}}">الاكتتاب</a></li>
            @endif
            @if(Auth::User()->hasRole('view_condition'))
            <li><a href="{{url('conditions')}}">تخصيص</a></li>
            @endif
            @if(Auth::User()->hasRole('view_report'))
            <li><a href="{{url('reports')}}">تقارير</a></li>
            @endif
            @if(Auth::User()->hasRole('view_form'))
            <li><a href="{{url('forms')}}">نماذج</a></li>
            @endif
            @if(Auth::User()->hasRole('view_condition')||auth()->user()->role_id==1)
            <li><a href="#">التخصيص</a></li>
            @endif
            @if(Auth::User()->hasRole('view_condition')||auth()->user()->role_id==1)
            <li><a href="#">الرديات</a></li>
            @endif
            @if(Auth::User()->hasRole('view_role'))
            <li><a href="{{url('roles')}}">الصلاحيات</a></li>
            @endif
            @if(Auth::User()->hasRole('view_user'))
            <li><a href="{{url('users')}}">المستخدمين</a></li>
            @endif
        </ul>
    </div>
<div class="page-content-wrapper">

        <div class="container-fluid"><a class="btn btn-link" role="button" id="menu-toggle" href="#menu-toggle"><i class="fa fa-bars"></i></a>
           <div class="row" style="margin-bottom: 15px;">

<div class="col-md-12" style="border-bottom: 1px solid #cab46b;">
<div style="display: inline-block;">
    <p><?php echo date('Y/m/d D'); ?></p>
</div>
<div style="display: inline-block;float: left;">
    <span class="top-option" id="span"></span>
    @auth 
        <span class="top-option">
        <div class="dropdown">
  <a type="button" class="dropdown-toggle" data-toggle="dropdown">
  <img src="{{url(Auth::User()->avatar)}}" class="profile-img"> <span class="caret">
</a>
  <div class="dropdown-menu dropdown-menu-animated">
    <a class="dropdown-item">
        <div class="row">
            <div class="col-md-4">
            <img src="{{url(Auth::User()->avatar)}}" class="profile-img"> 
            </div>
            <div class="col-md-8">
                {{Auth::User()->name}}
            </div>
        </div>
    </a>
    <a class="dropdown-item" href="/users/profile">الصفحة الشخصية</a>
      @if(Auth::User()->hasRole('view_role'))
          <a class="dropdown-item" href="{{url('/backups')}}">النسخ الاحتياطي</a>
      @endif
    <a class="dropdown-item btn btn-danger text-center" href="{{url('/logout')}}">تسجيل الخروج</a>
  </div>
</div>
        </span>
        @endauth
</div><br>
</div>
           </div>
@yield('content')
        </div>
</div>
</div>

    @yield('js')
<script>

function showLoading() {
  document.querySelector('#loading').classList.add('loading');
  document.querySelector('#loading-content').classList.add('loading-content');
}

function hideLoading() {
  document.querySelector('#loading').classList.remove('loading');
  document.querySelector('#loading-content').classList.remove('loading-content');
}

document.onreadystatechange = function() {
    if (document.readyState !== "complete") {
        setTimeout(hideLoading,500);
    } 
};
// When the user clicks on <div>, open the popup
var span = document.getElementById('span');

function time() {
    var d = new Date();
    var s = d.getSeconds();
    var m = d.getMinutes();
    var h = d.getHours();
    span.textContent =
        ("0" + h).substr(-2) + ":" + ("0" + m).substr(-2) + ":" + ("0" + s).substr(-2);
}
//$(document).ready(function() {
//    $('.table').DataTable({
//        language: {'url': '//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Arabic.json'},
//        "bPaginate": false,
//    });
//} );
setInterval(time, 1000);
</script>


</body>
</html>