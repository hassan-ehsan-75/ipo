@extends('layouts.new')
@section('title','الاكتتاب')
@section('content')
<div class="container-fluid">
    <h1 class="text-center">الاكتتاب</h1>
    <div class="row">
        <div class="col-12 text-center"><a type="button" href="{{url('/stocks/create/1')}}" class="btn btn-primary" type="button" style="margin-right: 10px;margin-left: 10px;background: #2da134;border-radius: 35px;padding-top: 10px;padding-bottom: 10px;padding-left: 20px;padding-right: 20px;">تسجيل اكتتاب جديد</a>
      </div>
    </div>
</div>
@if(session()->has('error'))
    <div class="form-group text-center mt-1">
        <label class="alert alert-warning">{{ session()->get('error')}}</label>
    </div>
@endif
@if(session()->has('success'))
    <div class="form-group text-center mt-1">
        <label class="alert alert-success">{{ session()->get('success')}}</label>
    </div>
@endif
<div class="container shadow" style="padding-top: 25px;margin-top: 30px;">
    {{--<div style="display: inline-block;width:50%;">--}}
    {{--<label>الفرز</label>--}}
    {{--<select class="option-control">--}}
    {{--<option>1</option>--}}
    {{--</select>--}}
    {{--</div>--}}
    <div  style="display: inline-block;width:100%;text-align:center">

        <label>بحث</label>
        <form style="display: inline-block;" method="GET" action="{{url('/stocks')}}">
            <input type="text" class="option-control" name="search" value="{{request('search')}}">
            <button type="submit" class="btn btn-secondary option-control mb-1">ابحث</button>
        </form>

     
    
</div>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>الاسم الكامل</th>
                    <th>موبايل</th>
                    <th>هاتف</th>
                    <th>القيمة المالية </th>
                    <th>عدد الاسهم المراد الاكتتاب عليها</th>
                    <th>الشركة المقدم عليها</th>
                    <th>البنك المسجل</th>
                    <th>الحالة</th>
                    <th>تاريخ الإدخال</th>
                    <th>الاجراءات</th>
                </tr>
            </thead>
            <tbody>
            @foreach($stocks as $stock)
                <tr>
                    <td>{{$stock->full_name}}</td>
                    <td>{{$stock->mobile}}</td>
                    <td dir="ltr" style="direction: ltr">{{$stock->phone}}</td>
                    <td>{{$stock->total}}</td>
                    <td>{{$stock->stock_number}}</td>
                    <td>@if($stock->company!=null){{$stock->company['ar_name']}}@endif</td>
                    <td>@if($stock->bank!=null){{$stock->bank['ar_name']}}@endif</td>
                    <td>@if ($stock->status==0)<label class="btn btn-warning">انتظار</label>@else<label class="btn btn-success">مفعل</label>@endif</td>
                    <td>{{$stock->created_at}}</td>
                    <td>
                    <div class="dropdown">
  <a type="button" class="dropdown-toggle" data-toggle="dropdown">
  الإجراءات
</a>
  <div class="dropdown-menu" style="text-align: right;">
  @if(Auth::User()->hasRole('view_stock'))
                        <a  class="dropdown-item" href="{{url('/stocks/show',$stock->id)}}" class="btn btn-default" style="margin:5px"><i class="fa fa-eye"></i> معاينة</a>
                        @endif
                        @if(Auth::User()->hasRole('update_stock'))
                        <a class="dropdown-item" href="{{url('/stocks/edit',$stock->id)}}" class="btn btn-primary" style="margin:5px"><i class="fa fa-edit"></i> تعديل</a>
                        @endif
                        @if(Auth::User()->hasRole('delete_stock'))
                        <form action="{{url('/stocks/destroy',$stock->id)}}" method="post">
                            @csrf
                            {{method_field('DELETE')}}
                            <BUTTON type="submit"  class="dropdown-item" style="margin:5px"><i class="fa fa-trash"></i> حذف</BUTTON>
                        </form>
                        @endif
                        @if($stock->status==0)
                            <button  class="dropdown-item" style="margin:5px" data-stock="{{$stock->id}}"  data-toggle="modal" data-target="#myModal"><i class="fa fa-check"></i>تفعيل</button>
                        @endif
  </div>
</div> </td>
                </tr>
               @endforeach
            </tbody>
        </table>
    </div>
    <div class="container col-md-4" style="padding-bottom: 25px;">
    <nav>
    {{$stocks->links()}}
</nav>
    </div>
</div>
<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">تفعيل الاكتتاب</h4>
            </div>
            <div class="modal-body">
                <form id="active-form" action="" method="post" enctype="multipart/form-data">
                    @csrf
                    <div class="row">
                        <div class="col-md-9">
                            <div class="form-group">

                                <label class="control-label" for="rec_img">صوره الاشعار</label>
                                <input required type="file" class="form-control" name="rec_img" accept="image/*">

                                @error('identity_img')
                                <p style="color: red;">{{$message}}</p>
                                @endif
                            </div>
                        </div>
                        <div class="col-md-9">
                            <div class="form-group">

                                <label class="control-label" for="rec_img">صوره الاكتتاب بعد التوقيع</label>
                                <input required type="file" class="form-control" name="stock_img" accept="image/*">

                                @error('identity_img')
                                <p style="color: red;">{{$message}}</p>
                                @endif
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button id="active-submit" type="submit" class="btn btn-success" >تفعيل</button>
            </div>
        </div>

    </div>
</div>
@endsection
@section('js')
    <script>
        $('#myModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget); // Button that triggered the modal
            var stock_id = button.data('stock'); // Extract info from data-* attributes
            var modal = $(this)
            modal.find('#active-form').attr('action' , '{{route('stock.activate')}}'+'/'+stock_id)

        });
        $('#active-submit').on('click',function () {
            $('#active-form').submit();
        })
    </script>
@endsection