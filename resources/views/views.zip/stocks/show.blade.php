@extends('layouts.new')
@section('title','معاينة الاكتتاب')
@section('content')
<div class="container-fluid">
    <div class="container col-md-7">
        <h5 class="text-center">
            معاينة الاكتتاب
        </h5><br>
        <div class="row justify-content-center">
        @if(Auth::User()->hasRole('update_stock'))
            <div class="col-md-3 text-center">
                <a type="button" href="{{url('/stocks/edit',$stock->id)}}" class="btn btn-primary"><i class="fa fa-edit"></i> تعديل</a>
            </div>
        @endif
        @if(Auth::User()->hasRole('delete_stock'))
            <div class="col-md-3 text-center">
                <a type="button"  class="btn btn-danger"><i class="fa fa-trash"></i> حذف</a>
            </div>
        @endif
        @if(Auth::User()->hasRole('view_stock'))
        <div class="col-md-3 text-center">
                <a href="{{url('/reports/singleStock',$stock->id)}}" type="button" class="btn btn-secondary"><i class="fa fa-print"></i> طباعة</a>
            </div>
            <div class="col-md-3 text-center">
                <a href="{{url('/stocks')}}" type="button" class="btn btn-default"><i class="fa fa-list"></i> العودة</a>
            </div>
        @endif
        </div>
    </div>
    <div class="container shadow" style="margin-top: 20px;padding-top:15px;padding-bottom:15px">
    <div class="row">
        <div class="col-md-12">
            <p>1- <strong>اسم الشركة المصدرة:</strong> /{{$stock->company->ar_name}}/ </p>
            <p>2- <strong>عدد الأسهم المطروحة وسعر الاصدار:</strong></p>
            <p>عدد الاسهم المعروضة: /{{$stock->company->min_stock}}/ وقيمتها الاسمية /</p>
        </div>
    </div>
    <hr>
        <div class="row">
        
        <div class="col-md-12">
            <h5>3-المكتتب الطبيعي</h5>
            <table class="table table-bordered">
            <thead>
                <th>الاسم</th>
                <th>اسم الأب</th>
                <th>اسم الأم</th>
                
            </thead>
            <tbody>
                <tr>
                    <td>{{$stock->full_name}}</td>
                    <td>{{$stock->father}}</td>
                    <td>{{$stock->mother}}</td>
                </tr>
            </tbody>
        </table>
        </div>
        </div>
        <div class="row">
        <div class="col-md-12">
            <table class="table table-bordered">
                <thead>
                    <th>اسم الجد</th>
                    <th>اسم العائلة</th>
                    <th>الجنسية</th>
                </thead>
                <tbody>
                    <tr>
                        <td>{{$stock->grand_father_name}}</td>
                        <td>{{$stock->last_name}}</td>
                        <td>{{$stock->nation}}</td>
                    </tr>
                </tbody>
            </table>
        </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <table class="table table-bordered">
                    <thead>
                        <th>مكان وتاريخ الولادة</th>
                        <tH>الجنس</tH>
                    </thead>
                    <tbody>
                        <tr>
                            <td>{{$stock->birthday}}</td>
                            <td>{{$stock->gender}}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <h5>4-بطاقة التعريف</h5>
                <table class="table table-bordered">
                    <thead>
                        <th>نوع الوثيقة</th>
                        <th>الرقم</th>
                        <th>جهة الاصدار</th>
                        <th>تاريخ الاصدار</th>
                    </thead>
                    <tbody>
                    <tr>
                    <td>{{$stock->id_type}}</td>
                    <td>{{$stock->p_number}}</td>
                    <td>{{$stock->id_from}}</td>
                    <td>{{$stock->id_date}}</td>
                    </tr>
                    
                    </tbody>
                </table>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <h5>5-العنوان/الموطن المختار</h5>
                <table class="table table-bordered">
                    <thead>
                        <th>العنوان</th>
                        <th>المدينة</th>
                    </thead>
                    <tbody>
                        <tr>
                            <td>{{$stock->address}}</td>
                            <td>{{$stock->city}}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="row">
        <div class="col-md-12">
            <table class="table table-bordered">
                <thead>
                    <th>موبايل</th>
                    <th>هاتف</th>
                    <th>فاكس</th>
                    <th>البريد الالكتروني</th>
                </thead>
                <tbody>
                    <tr>
                    <td dir="ltr" style="direction: ltr">{{$stock->mobile}}</td>
                    <td dir="ltr" style="direction: ltr">{{$stock->phone}}</td>
                    <td dir="ltr" style="direction: ltr">{{$stock->fax}}</td>
                    <td>{{$stock->email}}</td>
                    </tr>
                    
                </tbody>
            </table>
        </div>
        </div>
        <div class="row">
        <div class="col-md-12">
            <h5>6-معلومات عن الاسهم المكتتب بها</h5>
            <table class="table table-bordered">
                <thead>
                    <th>عدد الأسهم المكتتب بها</th>
                    <th>قيمة الأسهم المكتتبة</th>
                </thead>
                <tbody>
                    <tr>
                        <td>{{$stock->stock_number}}</td>
                        <td>{{$stock->total}}</td>
                    </tr>
                </tbody>
            </table>
        </div>
        </div>
        
        <div class="row">
            <div class="col-md-12">
                <p>
                    أقر بأن جميع المعلومات الواردة أعلاه صحيحة كاملة وأوافق على اكتتابي في أسهم (أو إسناد) الشركة أعلاه,
                    هذا وأقر بأنني تسلمت نسخة من نشرة الإصدار والنظام الأساسي, وقد اطلعت على كافة محتوياتها ودرستها بعناية وفهمت مضمونها, 
                    وبناء على ذلك تم اكتتابي بالأسهم أو  (الأسناد) المذكورة, علماً بأنني لا أتنازل
                    عن حقي بمطالبة الشركة والرجوع إليها بكل عطل وضرر ينجم من جراء إضافة معلومات غير صحيحة أو غير كافية
                    في نشرة الإصدار أو نتيجة حذف معلومات قد تؤثر على قبولي بالاكتتاب في حال إضافتها النشرة.
                    <br>
                    هذا وأقر بأنه يحق لكم رفض هذا الطلب في حال عدم تمكنكم من تحصيل قيمة الاكتتاب لأي سبب كان.<br>
                    إن الطلب مستوفي للشروط أعلاه والموقع أصولاً يشكل إيجاباً ملزماً للمكتتب لايحق الرجوع عنه.
                </p>
            </div>
        </div>
    </div>
</div>
@endsection