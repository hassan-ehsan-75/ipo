@extends('layouts.new')
@section('title','إضافة اكتتاب')
@section('css')

    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/css/bootstrap-select.min.css">
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/js/bootstrap-select.min.js"></script>

    <!-- (Optional) Latest compiled and minified JavaScript translation files -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/js/i18n/defaults-*.min.js"></script>
    <script src="https://unpkg.com/html5-qrcode@2.0.9/dist/html5-qrcode.min.js"></script>
@endsection
@section('content')
    <div class="container-fluid">
        <div class="container">
            <h1 class="text-center">
                <?php if($type == 1):?>
                إضافة جديد طبيعي
                <?php elseif($type == 2):?>
                إضافة جديد إعتباري
                <?php endif;?>
            </h1>
        </div>
        <div class="container">
            <form method="POST" action="{{url('/stocks/store',$type)}}" enctype="multipart/form-data">
                @csrf
                @if(session()->has('success'))
                    <div class="form-group text-center">
                        <label class="alert alert-success">{{ session()->get('success')}}</label>
                    </div>
                @endif
                @if(count($errors)>0)
                    <div class="form-group text-center">
                        <label class="alert alert-danger">{{ $errors->first()}}</label>
                    </div>
                @endif
                @if(session()->has('error'))
                    <div class="form-group text-center">
                        <label class="alert alert-danger">{{ session()->get('error')}}</label>
                    </div>
                @endif

                <div class="row">
                    <div class="col-md-4">
                        <label class="control-label" for="name">الاسم </label>
                        <input required ="" type="text" class="form-control" name="full_name" value="{{old('full_name')}}">
                        @error('full_name')
                        <p style="color: red;">{{$message}}</p>
                        @endif
                    </div>
                    <div class="col-md-4">
                        <label class="control-label" for="name">اسم الأب </label>
                        <input required ="" type="text" class="form-control" name="father" value="{{old('father')}}">
                        @error('father')
                        <p style="color: red;">{{$message}}</p>
                        @endif
                    </div>
                    <div class="col-md-4">
                        <label class="control-label" for="name">اسم الأم </label>
                        <input required ="" type="text" class="form-control" name="mother" value="{{old('mother')}}">
                        @error('mother')
                        <p style="color: red;">{{$message}}</p>
                        @endif
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">

                            <label class="control-label" for="name">اسم الجد </label>
                            <input required ="" type="text" class="form-control" name="grand_father_name" value="{{old('grand_father_name')}}">
                            @error('grand_father_name')
                            <p style="color: red;">{{$message}}</p>
                            @endif

                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">

                            <label class="control-label" for="name">اسم العائلة</label>
                            <input required type="text" class="form-control" name="last_name" value="{{old('last_name')}}">

                            @error('last_name')
                            <p style="color: red;">{{$message}}</p>
                            @endif
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">

                            <label class="control-label" for="name">الجنسية</label>
                            <input required type="text" class="form-control" name="nation" value="{{old('nation')}}">

                            @error('nation')
                            <p style="color: red;">{{$message}}</p>
                            @endif
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">

                            <label class="control-label" for="name">تاريخ الولادة</label>
                            <input required type="date" class="form-control" name="birthday"
                                   placeholder="تاريخ ومكان الولادة" value="{{old('birthday')}}">

                            @error('birthday')
                            <p style="color: red;">{{$message}}</p>
                            @endif
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">

                            <label class="control-label" for="name">الجنس</label>
                            <select required class="form-control" name="gender" placeholder="الجنس" value="{{old('gender')}}">
                                <option value="ذكر">ذكر</option>
                                <option value="انثى">انثى</option>
                            </select>

                            @error('gender')
                            <p style="color: red;">{{$message}}</p>
                            @endif
                        </div>
                    </div>
                </div>

                <div class="row">

                    <div class="col-md-12">
                        <h5>بطاقة التعريف</h5>
                    </div>
                    <div class="col-md-4">
                        <label class="control-label">تاريخ الإصدار</label>
                        <input required type="date" class="form-control" name="id_date" value="{{old('id_date')}}">
                        @error('id_date')
                        <p style="color: red;">{{$message}}</p>
                        @endif
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">

                            <label class="control-label" for="name">صوره الهويه</label>
                            <input required type="file" class="form-control" name="identity_img" accept="image/*">

                            @error('identity_img')
                            <p style="color: red;">{{$message}}</p>
                            @endif
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <div id="qr-reader"></div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <label class="control-label">نوع الوثيقة</label>
                        <select name="id_type" class="form-control" value="{{old('id_type')}}">
                            <option value="بطاقة شخصية ">بطاقة شخصية</option>
                            <option value="جواز سفر">جواز سفر</option>
                        </select>
                        @error('id_type')
                        <p style="color: red;">{{$message}}</p>
                        @endif
                    </div>
                    <div class="col-md-4">
                        <label class="control-label">الرقم</label>
                        <input required type="text" class="form-control" name="p_number" value="{{old('p_number')}}">
                        @error('p_number')
                        <p style="color: red;">{{$message}}</p>
                        @endif
                    </div>
                    <div class="col-md-4">
                        <label class="control-label">جهة الإصدار</label>
                        <input required type="text" class="form-control" name="id_from" value="{{old('id_from')}}">
                        @error('id_from')
                        <p style="color: red;">{{$message}}</p>
                        @endif
                    </div>

                </div>
                <Br>

                <div class="row">


                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">

                            <label class="control-label" for="name">ايميل</label>
                            <input required type="text" class="form-control" name="email" placeholder="ايميل" value="{{old('email')}}">
                            @error('email')
                            <p style="color: red;">{{$message}}</p>
                            @endif

                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">

                            <label class="control-label" for="name">هاتف</label>
                            <input required type="text" style="direction: ltr" class="form-control" name="phone" placeholder="هاتف" value="{{old('phone')}}">
                            @error('phone')
                            <p style="color: red;">{{$message}}</p>
                            @endif

                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">

                            <label class="control-label" for="name">موبايل</label>
                            <input required type="text" style="direction: ltr" class="form-control" name="mobile" placeholder="موبايل" value="{{old('mobile')}}">
                            @error('mobile')
                            <p style="color: red;">{{$message}}</p>
                            @endif

                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">

                            <label class="control-label" for="name">فاكس</label>
                            <input required type="text" class="form-control" name="fax" placeholder="فاكس" value="{{old('fax')}}">
                            @error('fax')
                            <p style="color: red;">{{$message}}</p>
                            @endif

                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">

                            <label class="control-label" for="name">المدينة</label>
                            <input required type="text" class="form-control" name="city" placeholder="المدينة" value="{{old('city')}}">
                            @error('city')
                            <p style="color: red;">{{$message}}</p>
                            @endif

                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">

                            <label class="control-label" for="name">عنوان</label>
                            <input required type="text" class="form-control" name="address" placeholder="عنوان" value="{{old('address')}}">
                            @error('address')
                            <p style="color: red;">{{$message}}</p>
                            @endif

                        </div>
                    </div>
                </div>
                <div class="row">

                    <div class="col-md-6">
                        <div class="form-group">

                            <label class="control-label" for="name">عدد الاسهم المراد الاكتتاب عليها</label>
                            <input required type="number" class="form-control" name="stock_number" step="any" id="stock_number"
                                   placeholder="عدد الاسهم المراد الاكتتاب عليها" value="{{old('stock_number')}}">

                            @error('stock_number')
                            <p style="color: red;">{{$message}}</p>
                            @endif
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">

                            <label class="control-label" for="name">القيمه الماليه</label>
                            <input required type="number" class="form-control disabled" name="total"  id="total"
                                   placeholder="القيمه الماليه" value="{{old('total')}}">
                            @error('total')
                            <p style="color: red;">{{$message}}</p>
                            @endif

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">الشركة المسجل لديها</label>
                            <select id="company_id" name="company_id" class="selectpicker form-control"
                                    data-live-search="true" data-live-search-style="begins" value="{{old('company_id')}}">
                                @foreach($companies as $company)
                                    <option value="{{$company->id}}">{{$company->ar_name}}</option>
                                @endforeach
                            </select>
                            @error('company_id')
                            <p style="color: red;">{{$message}}</p>
                            @endif
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">البنك المسجل</label>
                            <select id="bank_id" name="bank_id" class="selectpicker form-control"
                                    data-live-search="true" data-live-search-style="begins" value="{{old('bank_id')}}">
                                @foreach($banks as $bank)
                                    <option value="{{$bank->id}}">{{$bank->ar_name}}</option>
                                @endforeach
                            </select>
                            @error('bank_id')
                            <p style="color: red;">{{$message}}</p>
                            @endif
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group text-center">
                            <button type="submit" class="btn btn-primary-big">حفظ</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection

@section('js')
    <script>
        $('.selectpicker').selectpicker('refresh');


        function onScanSuccess(decodedText, decodedResult) {
            console.log(`Code scanned = ${decodedText}`, decodedResult);
        }
        var html5QrcodeScanner = new Html5QrcodeScanner(
            "qr-reader", {fps: 10, qrbox: 250});
        html5QrcodeScanner.render(onScanSuccess);
        $('#stock_number').on('change',function () {
            $('#total').val($('#stock_number').val()*100)
        })
    </script>
@endsection